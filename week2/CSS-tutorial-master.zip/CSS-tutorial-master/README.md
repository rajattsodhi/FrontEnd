# Lab 2: CSS tutorial

This repository contains an HTML and a CSS file in a separate folder, with another folder for images.

To preserve the original CSS file and work on your own changes, duplicate it with a different name, change the link in the HTML `head` section, and start experimenting.

Create as many CSS files as you like for different experiments! If it all goes wrong, duplicate the original again.
